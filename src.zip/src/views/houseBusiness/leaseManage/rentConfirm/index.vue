<template>
  <div>租金确认</div>
</template>
