<template>
  <div>安全检查</div>
</template>
